#!/usr/bin/env bash
# stallspy.sh — container-side py-spy sampler: EngineCore + all workers, 5s cadence
# Runs INSIDE qwen38-flash-next. Output: /tmp/stallspy/*.dump
# Usage (from host): docker exec -d qwen38-flash-next bash /tmp/stallspy.sh 150
set -u
DUR="${1:-150}"
OUT=/tmp/stallspy
mkdir -p $OUT
rm -f $OUT/*.dump 2>/dev/null
PYSPY=/opt/venv/bin/py-spy

pids=$(pgrep -f 'VLLM::' | tr '\n' ' ')
echo "sampling pids: $pids for ${DUR}s every 5s" > $OUT/manifest.txt
ps aux | grep -a 'VLLM::' | grep -v grep >> $OUT/manifest.txt

end=$(( $(date +%s) + DUR ))
while [ $(date +%s) -lt $end ]; do
    ts=$(date +%H%M%S)
    for pid in $pids; do
        name=$(ps -p $pid -o comm= 2>/dev/null | tr -d ' ')
        $PYSPY dump --pid $pid > $OUT/${ts}_${name}_${pid}.dump 2>&1 || true
    done
    sleep 5
done
echo "capture done: $(ls $OUT/*.dump 2>/dev/null | wc -l) dumps at $(date +%H:%M:%S)" >> $OUT/manifest.txt
