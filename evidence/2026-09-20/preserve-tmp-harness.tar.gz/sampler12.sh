#!/usr/bin/env bash
# sampler12.sh — 30s-interval samples of KV cache usage + TP0 worker RSS
for i in $(seq 1 60); do
  ts=$(date +%H:%M:%S)
  cu=$(curl -s -m 5 http://localhost:8021/metrics | grep -a '^vllm:gpu_cache_usage' | tail -1 | awk '{print $NF}')
  rss=$(docker exec qwen38-flash-next bash -c 'grep VmRSS /proc/$(pgrep -f "VLLM::Worker_TP0" | head -1)/status' 2>/dev/null | grep -oE '[0-9]+')
  echo "$ts cache_usage=$cu tp0_rss_kB=$rss" >> /tmp/sampler12.log
  sleep 30
done
