#!/usr/bin/env python3
# patch-capoverride.py — v24h2: optional CAP_SIZES_LIST override for the
# capture-size generator (skip transitional sizes that fault at capture on
# this platform: 16-way full 1..16 capture hit DEVICE_LOST at 23:09:12; 1..12
# captures clean). Guard unchanged: boot refuses unless MNS is covered.
import hashlib, sys

P = "/home/bonz/fn-recipe-int4/start.sh"
src = open(P, "r", encoding="utf-8", newline="").read()
h0 = hashlib.md5(src.encode()).hexdigest()

OLD = 'CAP_SIZES_JSON="[$(seq -s, 1 "$MAX_NUM_SEQS")]"'
NEW = '''if [[ -n "$CAP_SIZES_LIST" ]]; then
  # v24h2: explicit list (e.g. "1,2,3,4,5,6,7,8,12,16") — skips transitional
  # sizes that fault at capture time on this stack. Must still cover MNS.
  if ! echo "$CAP_SIZES_LIST" | grep -qE "^[0-9]+(,[0-9]+)*$"; then
    err "v24h2: CAP_SIZES_LIST must be digits+commas (got: '$CAP_SIZES_LIST')"; exit 1
  fi
  CAP_SIZES_JSON="[$CAP_SIZES_LIST]"
else
  CAP_SIZES_JSON="[$(seq -s, 1 "$MAX_NUM_SEQS")]"
fi'''

n = src.count(OLD)
if n != 1:
    print(f"ABORT: marker x{n} (need 1); md5={h0}")
    sys.exit(1)
if "V24H2_OVERRIDE" in src:
    print("ABORT: already patched")
    sys.exit(1)

out = src.replace(OLD, NEW + "  # V24H2_OVERRIDE")
open(P, "w", encoding="utf-8", newline="").write(out)
h1 = hashlib.md5(out.encode()).hexdigest()
print(f"PATCH_OK md5 {h0} -> {h1}")
print("V24H2_OVERRIDE_APPLIED")
