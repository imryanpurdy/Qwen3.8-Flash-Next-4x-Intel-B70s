#!/usr/bin/env bash
# ============================================================================
# wedge-watchdog-v2.sh — census-informed rewrite, v2.5 HARDENED (2026-09-19)
#
# Replaces wedge-watchdog.sh per docs/2026-09-19-wedge-census-resplit.md:
#   D1: byte-size growth check false-negatives on tqdm CR frames -> use MTIME
#   D2: 3x60s stall limit inside healthy envelope -> phase-aware thresholds
#   D3: device/signature paths killed on single probe -> require 2 consecutive
#   D4: no decision record -> wd-decisions.jsonl is the primary evidence
# Never kills on broadcast-warning COUNT. Kill requires mute + blocked workers.
# Before any kill: wchan/stat capture of all workers INTO the wedge log.
#
# v2.5 (2026-09-19 engine-true hardening, per stall #3/#4 autopsy):
#   F1. ENGINE-TRUE HEALTH in serving: /v1/models stays 200 while EngineCore is
#       dead (APIServer survives) — the blind spot that hid both stalls. In the
#       serving phase health is decided by a 1-token generation probe, and the
#       mtime "progressing" shortcut is DISABLED (the APIServer keeps writing
#       log lines through a wedge, so fresh mtime proves nothing in serving).
#   F2. Gen probe runs ONLY in serving phase (pre/ple/postkv are boot; the gen
#       stack is not up yet and would false-fail).
#   F3. 2 CONSECUTIVE gen-bad probes in serving => capture-and-restart even
#       when server.log mtime is fresh.
#   F4. Stat-excuse: a 1-token probe can be QUEUED behind a full-width burst
#       (MNS=8, 8 in flight -> 9th req queued) and time out while the engine
#       is completely healthy. The engine demonstrably publishing NONZERO
#       "Avg generation throughput" in server.log without a wedge marker after
#       it counts as alive; a wedged engine goes 0.0 then silence/60s-warnings.
#   F5. Self-guard (flock + pidfile fallback) so a manually-launched v2 and
#       start.sh's spawn cannot both run (stall4: pid 3233940 duplicate);
#       cold-start grace so a relaunch that takes <2 probes is not burned
#       as an exit.
#   F6. Serving-phase fallback for phase(): server.log "Application startup
#       complete" (per-boot log file) settles serving detection even when the
#       observer's boot_clock.jsonl cannot be parsed.
#   F7. Two latent defects found while testing v2.5: phase() compared the
#       boot_clock ready timestamp against the probe time (always past ->
#       boot_clock serving detection NEVER fired) — now compared against the
#       container start epoch; container_start_epoch() piped ISO through
#       `xargs date -d +%s` (arg-order bug -> always 0) — now date -d "$iso".
# ============================================================================
set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
INTERVAL="${WEDGE_WATCHDOG_INTERVAL:-60}"
RETRIES="${WEDGE_WATCHDOG_RETRIES:-3}"
CONTAINER_NAME="${CONTAINER_NAME:-qwen38-flash-next}"
PORT="${PORT:-8021}"
SERVED_MODEL_NAME="${SERVED_MODEL_NAME:-qwen3.8-flash-next}"
PREFLIGHT_XPU_COUNT="${PREFLIGHT_XPU_COUNT:-4}"
GEN_TIMEOUT="${WEDGE_WATCHDOG_GEN_TIMEOUT:-15}"
COLD_GRACE="${WEDGE_WATCHDOG_COLD_GRACE:-2}"   # probes to wait for a container that vanished (relaunch window)
SERVER_LOG="$SCRIPT_DIR/.run/server.log"
DECISIONS="$SCRIPT_DIR/.run/wd-decisions.jsonl"
mkdir -p "$SCRIPT_DIR/.run"

info(){ echo -e "\033[1;34m[INFO]\033[0m  $*"; }
ok(){   echo -e "\033[1;32m[ OK ]\033[0m  $*"; }
err(){  echo -e "\033[1;31m[ERR ]\033[0m  $*"; }

# F5: refuse to run as a duplicate (start.sh may already own the spawn line).
# Primary: flock; fallback: pidfile liveness (POSIX, no util-linux needed).
self_guard(){
    local pidfile="$SCRIPT_DIR/.run/wd-v2.pid"
    if command -v flock >/dev/null 2>&1; then
        exec 9>"$SCRIPT_DIR/.run/wd-v2.lock"
        if ! flock -n 9; then
            err "another wedge-watchdog-v2 holds .run/wd-v2.lock — exiting (duplicate-suppression)"
            exit 1
        fi
    else
        if [[ -f "$pidfile" ]] && kill -0 "$(cat "$pidfile" 2>/dev/null)" 2>/dev/null; then
            err "another wedge-watchdog-v2 pid $(cat "$pidfile") is alive — exiting (duplicate-suppression)"
            exit 1
        fi
    fi
    echo $$ > "$pidfile" 2>/dev/null || true
}
self_guard

# ---- helpers ----------------------------------------------------------------
container_running(){ docker ps --format '{{.Names}}' 2>/dev/null | grep -qx "$CONTAINER_NAME"; }
container_start_epoch(){
    local iso
    iso=$(docker inspect -f '{{.State.StartedAt}}' "$CONTAINER_NAME" 2>/dev/null)
    [[ -n "$iso" ]] && date -d "$iso" +%s 2>/dev/null || echo 0
}
health_ok(){
    curl -fsS -m 8 "http://localhost:$PORT/v1/models" 2>/dev/null | grep -q "$SERVED_MODEL_NAME"
}
# Engine-true health: /v1/models stays 200 while EngineCore is dead (APIServer
# survives) — the blind spot that hid two stalls. Probe = 1-token generation.
gen_health_ok(){
    curl -fsS -m "$GEN_TIMEOUT" "http://localhost:$PORT/v1/completions" \
        -H 'Content-Type: application/json' \
        -d "{\"model\":\"$SERVED_MODEL_NAME\",\"prompt\":\"hi\",\"max_tokens\":1}" \
        2>/dev/null | grep -q '"choices"'
}
# F4: stat-excuse. True if the engine demonstrably published NONZERO generation
# throughput recently and no wedge/deadline marker appears after it. (A real
# wedge: 0.0 tok/s then silence / shm_broadcast 60s-warnings only.)
engine_stats_alive(){
    local block ln_stats ln_warn
    block=$(tail -n 300 "$SERVER_LOG" 2>/dev/null) || return 1
    [[ -n "$block" ]] || return 1
    # last line with a NONZERO Avg generation throughput
    ln_stats=$(printf '%s\n' "$block" | grep -naE 'Avg generation throughput: *[1-9]' | tail -1 | cut -d: -f1)
    [[ -n "$ln_stats" ]] || return 1
    ln_warn=$(printf '%s\n' "$block" | grep -naE 'No available shared memory broadcast block|TimeoutError|EngineDead|sample_tokens' | tail -1 | cut -d: -f1)
    if [[ -n "$ln_warn" ]]; then
        # wedge/deadline marker AFTER the last nonzero stats line => engine is not publishing now
        [[ "$ln_stats" -gt "$ln_warn" ]] || return 1
    fi
    return 0
}
# Engine-true liveness for the serving phase (F1): probe, excused by stats.
engine_true_ok(){
    gen_health_ok && return 0
    engine_stats_alive
}

# ---- phase detection from observer clock + server.log markers ---------------
phase() {
    # boot_clock.jsonl carries observer phases when present
    local clock="$HOME/.run/observer/boot_clock.jsonl"
    if [[ -f "$clock" ]]; then
        local last cstart
        last=$(grep -a '"ready"' "$clock" | tail -1 | grep -aoE '"ts": [0-9.]+' | grep -oE '[0-9.]+')
        cstart=$(container_start_epoch)
        if [[ -n "$last" && -n "$cstart" && "$cstart" != "0" ]]; then
            # ready newer than THIS container's start epoch => serving phase
            if python3 -c "import sys; sys.exit(0 if float('$last') > float('$cstart') else 1)" 2>/dev/null; then
                echo serving; return
            fi
        fi
    fi
    # F6: per-boot server.log ("docker logs -f > .run/server.log" truncates per
    # launch) — startup marker is a serving fallback if boot_clock is stale
    # (e.g. observer restarted, watchdog relaunch without observer event).
    if container_running && grep -aqE 'Application startup complete|Uvicorn running on' "$SERVER_LOG" 2>/dev/null; then
        echo serving; return
    fi
    if grep -aq 'GPU KV cache size' "$SERVER_LOG" 2>/dev/null; then
        echo postkv; return
    fi
    if grep -aq 'ple_load_done\|Loading PLE\|per_layer_token_embd' "$SERVER_LOG" 2>/dev/null; then
        echo ple; return
    fi
    echo pre
}

log_mtime_age(){
    local m
    m=$(stat -c %Y "$SERVER_LOG" 2>/dev/null || echo 0)
    echo $(( $(date +%s) - m ))
}
log_size(){ [[ -f "$SERVER_LOG" ]] && wc -c < "$SERVER_LOG" 2>/dev/null || echo 0; }
log_tail(){ [[ -f "$SERVER_LOG" ]] && tail -n 200 "$SERVER_LOG" 2>/dev/null || true; }

# mute thresholds per phase (seconds without mtime advance that can mean dead)
thr_for(){
    case "$1" in
        pre)    echo 300 ;;  # PLE load: worst cadence 8.4s/it, frames 1-14s apart
        ple)    echo 300 ;;
        postkv) echo 900 ;;  # healthy KV->ready spans up to 687s observed
        serving) echo 180 ;; # serving stalls die fast; 3x interval
        *) echo 300 ;;
    esac
}

wchan_capture(){
    local cid="$1" out="$2"
    {
        echo "=== WCHAN/STAT CAPTURE $(date -u +%H:%M:%SZ) ==="
        # main + worker processes inside the container
        docker exec "$CONTAINER_NAME" sh -c '
            for p in /proc/[0-9]*/; do
                pid=${p#/proc/}; pid=${pid%/}
                cmd=$(tr "\0" " " < $p/cmdline 2>/dev/null | cut -c1-60)
                case "$cmd" in
                    *EngineCore*|*Worker_TP*|*PleOffloadWorker*|*APIServer*)
                        st=$(cat $p/stat 2>/dev/null | awk "{print \$3}")
                        wc=$(cat $p/wchan 2>/dev/null)
                        cpu=$(awk "{print \$14+\$15}" $p/stat 2>/dev/null)
                        echo "pid=$pid state=$st wchan=$wc cpu_jiffies=$cpu cmd=$cmd" ;;
                esac
            done' 2>/dev/null || echo "docker exec failed"
        echo "=== host-side vLLM worker processes ==="
        for pid in $(pgrep -f 'VLLM::Worker_TP|EngineCore' 2>/dev/null | head -8); do
            echo "hostpid=$pid state=$(cat /proc/$pid/stat 2>/dev/null | awk '{print $3}') wchan=$(cat /proc/$pid/wchan 2>/dev/null) cmd=$(tr '\0' ' ' < /proc/$pid/cmdline 2>/dev/null | cut -c1-50)"
        done
    } >> "$out" 2>&1
}

py_spy_capture(){
    # best-effort: py-spy dump on workers if container is up
    docker exec "$CONTAINER_NAME" /opt/venv/bin/py-spy dump --pid $(docker exec "$CONTAINER_NAME" pgrep -f 'EngineCore' | head -1) 2>/dev/null | head -40 || true
}

decide_and_log(){
    # $1=probe_ts $2=phase $3=mtime_age $4=size_delta $5=health $6=trigger $7=threshold $8=verdict $9=evidence_file
    printf '{"ts":%s,"phase":"%s","mtime_age_s":%s,"size_delta":%s,"health":"%s","trigger":"%s","threshold_s":%s,"verdict":"%s","evidence":"%s","workers":"%s"}\n' \
        "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "${9:-}" "$(docker exec "$CONTAINER_NAME" sh -c 'for p in /proc/[0-9]*/; do cmd=$(tr "\0" " " < $p/cmdline 2>/dev/null); case "$cmd" in *Worker_TP*) echo $(cat $p/wchan 2>/dev/null);; esac; done' 2>/dev/null | tr '\n' ',' )" \
        >> "$DECISIONS" 2>/dev/null || true
}

capture_and_kill(){
    local reason="$1" ts wlog
    ts=$(date -u +%Y%m%dT%H%M%SZ)
    wlog="$SCRIPT_DIR/.run/wedge-${ts}.log"
    {
        echo "=== WEDGE-DETected $(date -u) ==="
        echo "reason : $reason"
        echo "phase  : $(cat "$SCRIPT_DIR/.run/wd-phase-last" 2>/dev/null || echo unknown)"
        echo "--- last 200 lines: .run/server.log ---"
        log_tail
        echo "--- docker logs --tail 200 ---"
        docker logs --tail 200 "$CONTAINER_NAME" 2>/dev/null || true
    } > "$wlog"
    # THE capture that matters: worker states BEFORE anything is killed
    wchan_capture "$CONTAINER_NAME" "$wlog"
    py_spy_capture >> "$wlog" 2>&1 || true
    err "WEDGE-DETected ($reason). Captured (incl. wchan+pyspy) -> $wlog"
    local cpid
    cpid=$(docker inspect -f '{{.State.Pid}}' "$CONTAINER_NAME" 2>/dev/null || true)
    if [[ -n "$cpid" && "$cpid" != "0" ]] && kill -0 -- "-$cpid" 2>/dev/null; then
        kill -TERM -- "-$cpid" 2>/dev/null || true; sleep 2
        kill -KILL -- "-$cpid" 2>/dev/null || true
    fi
    docker rm -f "$CONTAINER_NAME" >/dev/null 2>&1 || true
    [[ -f "$SCRIPT_DIR/.run/logtail.pid" ]] && { kill "$(cat "$SCRIPT_DIR/.run/logtail.pid")" 2>/dev/null || true; rm -f "$SCRIPT_DIR/.run/logtail.pid"; }
    echo "$wlog"
}

sig_hits(){
    log_tail | grep -aiE 'guc_exec_queue_timedout_job|Engine reset: engine_class' | tail -1 || true
}

# bounded restart (retry budget shared by all paths), used by every trigger
restart_engine(){
    retries_used=$((retries_used+1))
    if [[ "$retries_used" -ge "$RETRIES" ]]; then
        err "watchdog-v2 GAVE UP after $retries_used restarts — engine wedged repeatedly despite $RETRIES restarts; human intervention required"
        echo "evidence: $1" >&2
        exit 1
    fi
    info "restart ${retries_used}/${RETRIES} (evidence: $1)"
    WEDGE_WATCHDOG_ALREADY_RUNNING=1 "$SCRIPT_DIR/start.sh" --launch >/dev/null 2>&1 || true
}

trap 'info "watchdog-v2 stopped (signal)"; exit 0' TERM INT
info "wedge-watchdog-v2.5 live: interval=${INTERVAL}s retries=${RETRIES} gen-timeout=${GEN_TIMEOUT}s cold-grace=${COLD_GRACE} engine-true probe, phase-aware, decision-logging -> $DECISIONS"

retries_used=0
sig_streak=0
gen_bad_streak=0
cold_streak=0
ever_healthy=false
last_size=$(log_size)

while :; do
    sleep "$INTERVAL"
    ts=$(date +%s)
    PHASE=$(phase)
    echo "$PHASE" > "$SCRIPT_DIR/.run/wd-phase-last"
    THR=$(thr_for "$PHASE")
    MAGE=$(log_mtime_age)
    SZ=$(log_size)
    SIZE_DELTA=$((SZ - last_size)); last_size=$SZ

    # ---- health probes -------------------------------------------------------
    # models-200 (APIServer) — supplementary; in serving it is NOT health (F1).
    HEALTH=bad; health_ok && { HEALTH=ok; ever_healthy=true; }
    # engine-true gen probe: serving phase ONLY (F2). Boot-phase gen would
    # false-fail with the engine not yet serving.
    GEN=skip; GENSTR=0
    if [[ "$PHASE" == "serving" ]]; then
        if engine_true_ok; then
            GEN=ok; gen_bad_streak=0; ever_healthy=true
        else
            GEN=bad; gen_bad_streak=$((gen_bad_streak+1))
        fi
        GENSTR=$gen_bad_streak
        # serving: engine-true decides, models-200 alone stays bad (F1)
        if [[ "$GEN" == "ok" ]]; then HEALTH=ok; else HEALTH=bad; fi
    fi

    # ---- healthy: nothing to decide -----------------------------------------
    if [[ "$HEALTH" == "ok" ]]; then
        sig_streak=0
        decide_and_log "$ts" "$PHASE" "$MAGE" "$SIZE_DELTA" "$HEALTH" "gen=$GEN" "$THR" healthy
        continue
    fi

    # ---- container gone (with grace for the relaunch window) -----------------
    if ! container_running; then
        cold_streak=$((cold_streak+1))
        decide_and_log "$ts" "$PHASE" "$MAGE" "$SIZE_DELTA" bad "cold=$cold_streak" "$THR" "container_down_${cold_streak}"
        if [[ "$cold_streak" -ge "$COLD_GRACE" ]]; then
            reason="container '$CONTAINER_NAME' not running after ${cold_streak} probes (never healthy this round)"
            if [[ "$ever_healthy" == "true" ]]; then
                reason="container exited after being healthy (${cold_streak} probes)"
            fi
            WLOG=$(capture_and_kill "$reason")
            cold_streak=0
            restart_engine "$WLOG"
        fi
        continue
    fi
    cold_streak=0

    # ---- engine-true serving wedge: 2 consecutive gen-bad, mtime irrelevant --
    # (F3) the APIServer keeps writing log lines through a wedge, so mtime is
    # fresh while EngineCore is dead — only the generation probe sees it.
    if [[ "$PHASE" == "serving" && "$GEN" == "bad" ]]; then
        if [[ "$GENSTR" -ge 2 ]]; then
            decide_and_log "$ts" "$PHASE" "$MAGE" "$SIZE_DELTA" bad "gen_streak=$GENSTR" "$THR" "engine_true_wedge_${GENSTR}"
            WLOG=$(capture_and_kill "engine-true wedge: generation probe failed ${GENSTR}x consecutive in serving (mtime_age=${MAGE}s — APIServer keeps writing; stats/$(sig_hits | head -c 80))")
            gen_bad_streak=0
            restart_engine "$WLOG"
        else
            decide_and_log "$ts" "$PHASE" "$MAGE" "$SIZE_DELTA" bad "gen_streak=$GENSTR" "$THR" "gen_bad_${GENSTR}"
        fi
        continue
    fi
    gen_bad_streak=0

    # ---- log advanced recently -> boot work progressing (NON-SERVING only) ---
    # (F1) in serving the mtime shortcut is DISABLED — an engine-wedged
    # APIServer keeps the log fresh, so progress there requires the gen probe.
    if [[ "$PHASE" != "serving" && "$MAGE" -lt 45 ]]; then
        sig_streak=0
        decide_and_log "$ts" "$PHASE" "$MAGE" "$SIZE_DELTA" bad progress "$THR" progressing
        continue
    fi

    # ---- dead signature (Xe2 reset): require 2 consecutive probes (D3) -------
    SIG=$(sig_hits)
    if [[ -n "$SIG" ]]; then
        sig_streak=$((sig_streak+1))
        decide_and_log "$ts" "$PHASE" "$MAGE" "$SIZE_DELTA" bad "sig_streak=$sig_streak" "$THR" "signature_pending_$sig_streak"
        if [[ "$sig_streak" -ge 2 ]]; then
            WLOG=$(capture_and_kill "Xe2 wedge signature x2: $SIG")
            sig_streak=0
            restart_engine "$WLOG"
        fi
        continue
    fi
    sig_streak=0

    # ---- muted: no health, log mtime stale past phase threshold --------------
    decide_and_log "$ts" "$PHASE" "$MAGE" "$SIZE_DELTA" bad "mute" "$THR" "mute_${MAGE}s_ge_${THR}s"
    if [[ "$MAGE" -ge "$THR" ]]; then
        WLOG=$(capture_and_kill "mute ${MAGE}s >= ${THR}s in phase $PHASE (wchan+pyspy captured pre-kill)")
        restart_engine "$WLOG"
    fi
done
