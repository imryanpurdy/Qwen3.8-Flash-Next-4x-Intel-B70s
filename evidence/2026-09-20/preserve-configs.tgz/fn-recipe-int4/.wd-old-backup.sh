#!/usr/bin/env bash
# ============================================================================
# wedge-watchdog-v2.sh — census-informed rewrite (2026-09-19)
#
# Replaces wedge-watchdog.sh per docs/2026-09-19-wedge-census-resplit.md:
#   D1: byte-size growth check false-negatives on tqdm CR frames -> use MTIME
#   D2: 3x60s stall limit inside healthy envelope -> phase-aware thresholds
#   D3: device/signature paths killed on single probe -> require 2 consecutive
#   D4: no decision record -> wd-decisions.jsonl is the primary evidence
# Never kills on broadcast-warning COUNT. Kill requires mute + blocked workers.
# Before any kill: wchan/stat capture of all workers INTO the wedge log.
# ============================================================================
set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
INTERVAL="${WEDGE_WATCHDOG_INTERVAL:-60}"
RETRIES="${WEDGE_WATCHDOG_RETRIES:-3}"
CONTAINER_NAME="${CONTAINER_NAME:-qwen38-flash-next}"
PORT="${PORT:-8021}"
SERVED_MODEL_NAME="${SERVED_MODEL_NAME:-qwen3.8-flash-next}"
PREFLIGHT_XPU_COUNT="${PREFLIGHT_XPU_COUNT:-4}"
SERVER_LOG="$SCRIPT_DIR/.run/server.log"
DECISIONS="$SCRIPT_DIR/.run/wd-decisions.jsonl"
mkdir -p "$SCRIPT_DIR/.run"

info(){ echo -e "\033[1;34m[INFO]\033[0m  $*"; }
ok(){   echo -e "\033[1;32m[ OK ]\033[0m  $*"; }
err(){  echo -e "\033[1;31m[ERR ]\033[0m  $*"; }

# ---- phase detection from observer clock + server.log markers ----
phase() {
    # boot_clock.jsonl carries observer phases when present
    local clock="$HOME/.run/observer/boot_clock.jsonl"
    if [[ -f "$clock" ]]; then
        local last
        last=$(grep -a '"ready"' "$clock" | tail -1 | grep -aoE '"ts": [0-9.]+' | grep -oE '[0-9.]+')
        if [[ -n "$last" ]]; then
            local now; now=$(date +%s)
            # ready newer than container start => serving phase
            if python3 -c "import sys; sys.exit(0 if float('$last') > float('$1') else 1)" 2>/dev/null; then
                echo serving; return
            fi
        fi
    fi
    if grep -aq 'GPU KV cache size' "$SERVER_LOG" 2>/dev/null; then
        echo postkv; return
    fi
    if grep -aq 'ple_load_done\|Loading PLE\|per_layer_token_embd' "$SERVER_LOG" 2>/dev/null; then
        echo ple; return
    fi
    echo pre
}

# Engine-true health: /v1/models stays 200 while EngineCore is dead (APIServer
# survives) — the blind spot that hid two stalls. Probe = 1-token generation.
gen_health_ok(){
    curl -fsS -m 12 "http://localhost:$PORT/v1/completions" \
        -H 'Content-Type: application/json' \
        -d "{\"model\":\"$SERVED_MODEL_NAME\",\"prompt\":\"hi\",\"max_tokens\":1}" \
        2>/dev/null | grep -q '"choices"'
}
container_running(){ docker ps --format '{{.Names}}' 2>/dev/null | grep -qx "$CONTAINER_NAME"; }
container_start_epoch(){
    docker inspect -f '{{.State.StartedAt}}' "$CONTAINER_NAME" 2>/dev/null | \
        xargs -r date -d +%s 2>/dev/null || echo 0
}
health_ok(){
    curl -fsS -m 8 "http://localhost:$PORT/v1/models" 2>/dev/null | grep -q "$SERVED_MODEL_NAME"
}
log_mtime_age(){
    local m
    m=$(stat -c %Y "$SERVER_LOG" 2>/dev/null || echo 0)
    echo $(( $(date +%s) - m ))
}
log_size(){ [[ -f "$SERVER_LOG" ]] && wc -c < "$SERVER_LOG" 2>/dev/null || echo 0; }
log_tail(){ [[ -f "$SERVER_LOG" ]] && tail -n 200 "$SERVER_LOG" 2>/dev/null || true; }

# mute thresholds per phase (seconds without mtime advance that can mean dead)
thr_for(){
    case "$1" in
        pre)    echo 300 ;;  # PLE load: worst cadence 8.4s/it, frames 1-14s apart
        ple)    echo 300 ;;
        postkv) echo 900 ;;  # healthy KV->ready spans up to 687s observed
        serving) echo 180 ;; # serving stalls die fast; 3x interval
        *) echo 300 ;;
    esac
}

wchan_capture(){
    local cid="$1" out="$2"
    {
        echo "=== WCHAN/STAT CAPTURE $(date -u +%H:%M:%SZ) ==="
        # main + worker processes inside the container
        docker exec "$CONTAINER_NAME" sh -c '
            for p in /proc/[0-9]*/; do
                pid=${p#/proc/}; pid=${pid%/}
                cmd=$(tr "\0" " " < $p/cmdline 2>/dev/null | cut -c1-60)
                case "$cmd" in
                    *EngineCore*|*Worker_TP*|*PleOffloadWorker*|*APIServer*)
                        st=$(cat $p/stat 2>/dev/null | awk "{print \$3}")
                        wc=$(cat $p/wchan 2>/dev/null)
                        cpu=$(awk "{print \$14+\$15}" $p/stat 2>/dev/null)
                        echo "pid=$pid state=$st wchan=$wc cpu_jiffies=$cpu cmd=$cmd" ;;
                esac
            done' 2>/dev/null || echo "docker exec failed"
        echo "=== host-side vLLM worker processes ==="
        for pid in $(pgrep -f 'VLLM::Worker_TP|EngineCore' 2>/dev/null | head -8); do
            echo "hostpid=$pid state=$(cat /proc/$pid/stat 2>/dev/null | awk '{print $3}') wchan=$(cat /proc/$pid/wchan 2>/dev/null) cmd=$(tr '\0' ' ' < /proc/$pid/cmdline 2>/dev/null | cut -c1-50)"
        done
    } >> "$out" 2>&1
}

py_spy_capture(){
    # best-effort: py-spy dump on workers if container is up
    docker exec "$CONTAINER_NAME" /opt/venv/bin/py-spy dump --pid $(docker exec "$CONTAINER_NAME" pgrep -f 'EngineCore' | head -1) 2>/dev/null | head -40 || true
}

decide_and_log(){
    # $1=probe_ts $2=phase $3=mtime_age $4=size_delta $5=health $6=trigger $7=threshold $8=verdict $9=evidence_file
    printf '{"ts":%s,"phase":"%s","mtime_age_s":%s,"size_delta":%s,"health":"%s","trigger":"%s","threshold_s":%s,"verdict":"%s","evidence":"%s","workers":"%s"}\n' \
        "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "${9:-}" "$(docker exec "$CONTAINER_NAME" sh -c 'for p in /proc/[0-9]*/; do cmd=$(tr "\0" " " < $p/cmdline 2>/dev/null); case "$cmd" in *Worker_TP*) echo $(cat $p/wchan 2>/dev/null);; esac; done' 2>/dev/null | tr '\n' ',' )" \
        >> "$DECISIONS" 2>/dev/null || true
}

capture_and_kill(){
    local reason="$1" ts wlog
    ts=$(date -u +%Y%m%dT%H%M%SZ)
    wlog="$SCRIPT_DIR/.run/wedge-${ts}.log"
    {
        echo "=== WEDGE-DETected $(date -u) ==="
        echo "reason : $reason"
        echo "phase  : $(cat "$SCRIPT_DIR/.run/wd-phase-last" 2>/dev/null || echo unknown)"
        echo "--- last 200 lines: .run/server.log ---"
        log_tail
        echo "--- docker logs --tail 200 ---"
        docker logs --tail 200 "$CONTAINER_NAME" 2>/dev/null || true
    } > "$wlog"
    # THE capture that matters: worker states BEFORE anything is killed
    wchan_capture "$CONTAINER_NAME" "$wlog"
    py_spy_capture >> "$wlog" 2>&1 || true
    err "WEDGE-DETected ($reason). Captured (incl. wchan+pyspy) -> $wlog"
    local cpid
    cpid=$(docker inspect -f '{{.State.Pid}}' "$CONTAINER_NAME" 2>/dev/null || true)
    if [[ -n "$cpid" && "$cpid" != "0" ]] && kill -0 -- "-$cpid" 2>/dev/null; then
        kill -TERM -- "-$cpid" 2>/dev/null || true; sleep 2
        kill -KILL -- "-$cpid" 2>/dev/null || true
    fi
    docker rm -f "$CONTAINER_NAME" >/dev/null 2>&1 || true
    [[ -f "$SCRIPT_DIR/.run/logtail.pid" ]] && { kill "$(cat "$SCRIPT_DIR/.run/logtail.pid")" 2>/dev/null || true; rm -f "$SCRIPT_DIR/.run/logtail.pid"; }
    echo "$wlog"
}

sig_hits(){
    log_tail | grep -aiE 'guc_exec_queue_timedout_job|Engine reset: engine_class' | tail -1 || true
}

trap 'info "watchdog-v2 stopped (signal)"; exit 0' TERM INT
info "wedge-watchdog-v2 live: interval=${INTERVAL}s retries=${RETRIES} mtime-based, phase-aware, decision-logging -> $DECISIONS"

retries_used=0
sig_streak=0
ever_healthy=false
last_size=$(log_size)

while :; do
    sleep "$INTERVAL"
    ts=$(date +%s)
    PHASE=$(phase "$ts")
    echo "$PHASE" > "$SCRIPT_DIR/.run/wd-phase-last"
    THR=$(thr_for "$PHASE")
    MAGE=$(log_mtime_age)
    SZ=$(log_size)
    SIZE_DELTA=$((SZ - last_size)); last_size=$SZ
    HEALTH=bad; health_ok && { HEALTH=ok; ever_healthy=true; }
    GEN=bad; gen_health_ok && GEN=ok
    # engine-true: a generation probe is required, models-200 alone is a blindspot
    if [[ "$HEALTH" == "ok" && "$GEN" != "ok" ]]; then HEALTH=bad; fi

    # healthy -> nothing to decide
    if [[ "$HEALTH" == "ok" ]]; then
        sig_streak=0
        decide_and_log "$ts" "$PHASE" "$MAGE" "$SIZE_DELTA" "$HEALTH" "gen=$GEN" "$THR" healthy
        continue
    fi

    # log advanced recently -> boot work progressing (mtime, not size, is truth)
    if [[ "$MAGE" -lt 45 ]]; then
        sig_streak=0
        decide_and_log "$ts" "$PHASE" "$MAGE" "$SIZE_DELTA" bad progress "$THR" progressing
        continue
    fi

    # dead signature (Xe2 reset): require 2 consecutive probes (D3)
    SIG=$(sig_hits)
    if [[ -n "$SIG" ]]; then
        sig_streak=$((sig_streak+1))
        decide_and_log "$ts" "$PHASE" "$MAGE" "$SIZE_DELTA" bad "sig_streak=$sig_streak" "$THR" "signature_pending_$sig_streak"
        if [[ "$sig_streak" -ge 2 ]]; then
            WLOG=$(capture_and_kill "Xe2 wedge signature x2: $SIG")
            retries_used=$((retries_used+1))
            [[ "$retries_used" -ge "$RETRIES" ]] && { err "watchdog-v2 GAVE UP after $retries_used restarts"; exit 1; }
            info "restart ${retries_used}/${RETRIES}"
            WEDGE_WATCHDOG_ALREADY_RUNNING=1 "$SCRIPT_DIR/start.sh" --launch >/dev/null 2>&1 || true
            sig_streak=0
        fi
        continue
    fi
    sig_streak=0

    if ! container_running; then
        if [[ "$ever_healthy" == "true" ]]; then
            WLOG=$(capture_and_kill "container exited after being healthy")
            retries_used=$((retries_used+1))
            [[ "$retries_used" -ge "$RETRIES" ]] && { err "watchdog-v2 GAVE UP after $retries_used restarts"; exit 1; }
            WEDGE_WATCHDOG_ALREADY_RUNNING=1 "$SCRIPT_DIR/start.sh" --launch >/dev/null 2>&1 || true
        fi
        continue
    fi

    # muted: no health, log mtime stale past phase threshold
    decide_and_log "$ts" "$PHASE" "$MAGE" "$SIZE_DELTA" bad "mute" "$THR" "mute_${MAGE}s_ge_${THR}s"
    if [[ "$MAGE" -ge "$THR" ]]; then
        WLOG=$(capture_and_kill "mute ${MAGE}s >= ${THR}s in phase $PHASE (wchan+pyspy captured pre-kill)")
        retries_used=$((retries_used+1))
        [[ "$retries_used" -ge "$RETRIES" ]] && { err "watchdog-v2 GAVE UP after $retries_used restarts"; exit 1; }
        info "restart ${retries_used}/${RETRIES} after mute"
        WEDGE_WATCHDOG_ALREADY_RUNNING=1 "$SCRIPT_DIR/start.sh" --launch >/dev/null 2>&1 || true
    fi
done
