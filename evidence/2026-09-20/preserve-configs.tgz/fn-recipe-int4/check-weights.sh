#!/usr/bin/env bash
# INT4 identity gate — Intel/Qwen3.8-Flash-Next-W4A16-AutoRound
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
info() { echo -e "\033[1;34m[INFO]\033[0m  $*"; }
ok()   { echo -e "\033[1;32m[ OK ]\033[0m  $*"; }
err()  { echo -e "\033[1;31m[ERR ]\033[0m  $*"; exit 1; }

MODEL_ID_FROZEN="Intel/Qwen3.8-Flash-Next-W4A16-AutoRound"
TREE_BYTES_EXPECTED=169000000000   # ~169GB incl. 102.5GB bf16 PLE
TREE_BYTES_FLOOR_GB=160
source .env
[[ "$MODEL_ID" == "$MODEL_ID_FROZEN" ]] || err "Wrong model: '$MODEL_ID' (expected $MODEL_ID_FROZEN)"
HUB_PATH="${HF_HOME:-$HOME/.cache/huggingface}/hub"
MP="$HUB_PATH/models--Intel--Qwen3.8-Flash-Next-W4A16-AutoRound"
SNAP="$(ls -d $MP/snapshots/*/ 2>/dev/null | head -1)" || true
[[ -d "$SNAP" ]] || err "No snapshot under $MP"
GB=$(( $(du -sL "$SNAP" | awk '{print $1}') / 1048576 ))
info "Snapshot: $SNAP (${GB} GiB logical)"
(( GB >= TREE_BYTES_FLOOR_GB )) || err "Tree only ${GB} GiB (< floor $TREE_BYTES_FLOOR_GB) — incomplete download"
python3 - <<'PY'
import json, glob
cfg = json.load(open(glob.glob('/home/bonz/hf-int4/hub/models--Intel--Qwen3.8-Flash-Next-W4A16-AutoRound/snapshots/*/config.json')[0]))
q = cfg.get('quantization_config', {})
assert q.get('quant_method') == 'auto-round', f'quant_method={q.get("quant_method")}'
assert q.get('bits') == 4, f'bits={q.get("bits")}'
print('quant OK: auto-round 4-bit, group', q.get('group_size'))
PY
ok "INT4 snapshot identity PASS"
